/* ═══════════════════════════════════════════════════════════════════
   HYDROX B&R AI  ·  main.js
   Se carga en TODAS las páginas con defer.
   Módulos: header scroll · menú móvil · scroll reveal · formulario
═══════════════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  // ── 1. SCROLL HEADER ────────────────────────────────────────────
  const hdr = document.getElementById('header');
  if (hdr) {
    const tick = () => hdr.classList.toggle('scrolled', window.scrollY > 40);
    window.addEventListener('scroll', tick, { passive: true });
    tick();
  }

  // ── 2. MENÚ MÓVIL ───────────────────────────────────────────────
  const toggle = document.getElementById('nav-toggle');
  const links  = document.getElementById('nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      const isOpen = links.classList.toggle('open');
      toggle.textContent = isOpen ? '✕' : '☰';
      toggle.setAttribute('aria-expanded', isOpen);
    });
    links.querySelectorAll('a').forEach(a =>
      a.addEventListener('click', () => {
        links.classList.remove('open');
        toggle.textContent = '☰';
      })
    );
  }

  // ── 3. SCROLL REVEAL ────────────────────────────────────────────
  const io = new IntersectionObserver(
    entries => entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
    }),
    { threshold: 0.1 }
  );
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));

  // ── 4. FORMULARIO MULTI-PASO ────────────────────────────────────
  const form = document.getElementById('hydrox-form');
  if (!form) return;

  const WEBHOOK = 'https://hook.us2.make.com/z7bc9jug7fqt51x61ku8uyon9vijjovw';

  const steps   = form.querySelectorAll('.form-step');
  const tabs    = form.querySelectorAll('.form-tab');
  const dots    = form.querySelectorAll('.prog-dot');
  const success = document.getElementById('form-success');
  let current = 0;

  // Navegar entre pasos
  function goTo(n) {
    steps[current].classList.remove('active');
    tabs[current].classList.remove('active');
    tabs[current].classList.add('done');
    dots[current].classList.remove('active');
    current = n;
    steps[current].classList.add('active');
    tabs[current].classList.add('active');
    tabs[current].classList.remove('done');
    dots[current].classList.add('active');
    form.querySelector('.form-card').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  // Activar primer paso
  if (steps.length) {
    steps[0].classList.add('active');
    tabs[0].classList.add('active');
    dots[0].classList.add('active');
  }

  // Botones siguiente / anterior
  form.querySelectorAll('.btn-next').forEach(btn =>
    btn.addEventListener('click', () => { if (current < steps.length - 1) goTo(current + 1); })
  );
  form.querySelectorAll('.btn-prev').forEach(btn =>
    btn.addEventListener('click', () => { if (current > 0) goTo(current - 1); })
  );

  // Opciones personalizadas (radio / checkbox)
  form.querySelectorAll('.radio-opt').forEach(opt => {
    opt.addEventListener('click', () => {
      const name = opt.querySelector('input').name;
      form.querySelectorAll(`.radio-opt input[name="${name}"]`).forEach(inp =>
        inp.closest('.radio-opt').classList.remove('sel')
      );
      opt.classList.add('sel');
      opt.querySelector('input').checked = true;
    });
  });

  form.querySelectorAll('.check-opt').forEach(opt => {
    opt.addEventListener('click', () => {
      opt.classList.toggle('sel');
      opt.querySelector('input').checked = opt.classList.contains('sel');
    });
  });

  // Validación básica por paso
  function validateStep(n) {
    const step = steps[n];
    let ok = true;

    // Campos de texto / email obligatorios
    step.querySelectorAll('[required]').forEach(el => {
      el.style.borderColor = '';
      if (!el.value.trim()) { el.style.borderColor = '#e55'; ok = false; }
    });

    // Grupos de radio/checkbox obligatorios (tipo, modalidad, zona)
    step.querySelectorAll('[data-required]').forEach(group => {
      const checked = group.querySelectorAll('input:checked').length > 0;
      group.classList.toggle('group-error', !checked);
      if (!checked) ok = false;
    });

    return ok;
  }

  // Sobreescribir btn-next para validar primero
  form.querySelectorAll('.btn-next').forEach((btn) => {
    const newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);
    newBtn.addEventListener('click', () => {
      if (validateStep(current) && current < steps.length - 1) goTo(current + 1);
    });
  });

  // ── ENVÍO AL WEBHOOK DE MAKE.COM ───────────────────────────────
  // IMPORTANTE: se usa application/x-www-form-urlencoded con no-cors.
  // application/json con no-cors se degrada a text/plain y Make.com
  // no puede extraer los campos individuales → todos llegan vacíos.
  // URL-encoded es un "simple request" que no requiere preflight CORS.
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!validateStep(current)) return;

    // Honeypot anti-spam: campo oculto que solo bots llenan.
    // Si tiene valor, fingimos éxito sin enviar nada a Make.com.
    const honeypot = form.querySelector('#website');
    if (honeypot && honeypot.value.trim()) {
      form.querySelector('.form-card').style.display = 'none';
      if (success) success.style.display = 'block';
      return;
    }

    const submitBtn = form.querySelector('#submit-btn');
    submitBtn.textContent = 'Buscando propiedades…';
    submitBtn.disabled = true;

    // Construir objeto de datos
    const fd   = new FormData(form);
    const data = {};
    fd.forEach((v, k) => { data[k] = v; });

    // Zonas: múltiples checkboxes → un string separado por comas
    const zonaValues = [...form.querySelectorAll('input[name="zona"]:checked')].map(i => i.value);
    data.zona = zonaValues.join(', ');

    // Metadata
    data.fecha_solicitud = new Date().toISOString();
    data.fuente = 'sitio-web';
    delete data.website; // descartar campo honeypot

    try {
      // URLSearchParams genera application/x-www-form-urlencoded
      // Make.com lo recibe y extrae cada campo correctamente
      const payload = new URLSearchParams(data).toString();

      await fetch(WEBHOOK, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: payload,
        mode: 'no-cors' // Respuesta opaca, pero los datos SÍ llegan a Make.com
      });

      // Mostrar pantalla de éxito (asumimos éxito porque no-cors no devuelve status)
      form.querySelector('.form-card').style.display = 'none';
      if (success) success.style.display = 'block';

    } catch (err) {
      submitBtn.textContent = 'Error — intenta de nuevo';
      submitBtn.disabled = false;
      console.error('Webhook error:', err);
    }
  });

}); // fin DOMContentLoaded
